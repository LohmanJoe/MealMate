package com.mealproject.mealplanner17.ModelsAPI;

public class ExtendedIngredient {
    public int id;

    public String image;

    public String name;

    public String original;




}
